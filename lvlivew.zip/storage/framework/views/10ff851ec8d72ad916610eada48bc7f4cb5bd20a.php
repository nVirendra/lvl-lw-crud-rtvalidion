<?php $__env->startSection('content'); ?>
    <div class="flex justify-center">
        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('contact')->dom;
} elseif ($_instance->childHasBeenRendered('UnCM8Nr')) {
    $componentId = $_instance->getRenderedChildComponentId('UnCM8Nr');
    $componentTag = $_instance->getRenderedChildComponentTagName('UnCM8Nr');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UnCM8Nr');
} else {
    $response = \Livewire\Livewire::mount('contact');
    $dom = $response->dom;
    $_instance->logRenderedChild('UnCM8Nr', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lspl-desk-14/Documents/laravel-livewire-crud-master/resources/views/users/contacts.blade.php ENDPATH**/ ?>