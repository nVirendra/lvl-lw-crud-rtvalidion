<?php return array (
  'contact' => 'App\\Http\\Livewire\\Contact',
);